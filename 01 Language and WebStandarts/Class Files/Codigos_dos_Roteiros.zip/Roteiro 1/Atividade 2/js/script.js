
var botao = document.getElementById('data_exibicao');

function exibirData(){
    botao.innerHTML = Date();
}

