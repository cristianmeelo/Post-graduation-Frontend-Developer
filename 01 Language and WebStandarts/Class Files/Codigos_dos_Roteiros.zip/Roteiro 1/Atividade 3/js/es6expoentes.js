var x = 5;
var z = x ** 2; //operador de expoente (**) não existia nas versões anteriores
console.log("O valor da exponenciação de " + x + " por 2 é " + z);


var botao = document.getElementById('resultado').innerHTML = "O valor da exponenciação de " + x + " por 2 é " + z;
